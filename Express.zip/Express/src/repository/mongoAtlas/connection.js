const {MongoClient, ObjectId} = require('mongodb');

class Connection {

    getClientMongoDB = async () => {

        try {
            const uri = "mongodb+srv://devDB:CMGXj4AT1kyEpQ7J@clusternodeaula.w5kwg.gcp.mongodb.net/ClusterNODEAula?retryWrites=true&w=majority";
            const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
            await client.connect()
            const db = client.db("TrabalhoNODEAPI")
            return {client, db}
        } catch (error) {
            console.log('Connection.getClientMongoDB', error)
        }
    }

    getObjectId(stringID){
        try{
            return ObjectId(stringID)
        } catch(fail){
            console.log('Connection.getObjectId', fail)
        }
    }
}

module.exports = { Connection }