  

class CreateUseCase {

    constructor(presenter, repository, userDTO, collection) {
        this.presenter = presenter
        this.repository = repository
        this.userDTO = userDTO
        this.collection = collection
    }


    executeSave() {
        this.save(this.userDTO)
    }


    async save(user) {
        try {
            const newUser = await this.repository.save(this.collection, user, this.userDTO)
            this.presenter.ok(newUser)
        } catch (fail) {
            console.log('CreateUseCase.save', fail)
        }
    } 
}

module.exports = { CreateUseCase }