class DeleteUseCase {


    constructor(presenter, repository, collection) {
        this.presenter = presenter
        this.repository = repository
        this.collection = collection
    }

    async delete(userId) {
        try {
            const user = await this.repository.delete(this.collection, userId)
            this.presenter.ok(user)
        } catch (fail) {
            console.log('DeleteUseCase.delete', fail)
        }
    }

    async deleteByName(name) {
        try {
            const user = await this.repository.deleteByName(this.collection, name)
            this.presenter.ok(user)
        } catch (fail) {
            console.log('DeleteUseCase.deleteByName', fail)
        }
    }


}


module.exports = { DeleteUseCase }