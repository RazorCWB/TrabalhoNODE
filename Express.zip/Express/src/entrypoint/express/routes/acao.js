const { CreateUseCase } = require('../../../usecases/createusecase')
const { ListUseCase } = require('../../../usecases/listusecase')
const { DeleteUseCase } = require('../../../usecases/deleteusecase')
const { UpdateUseCase } = require('../../../usecases/updateusecase')
const { PresenterWEB } = require('../../../presenter/presenterweb')
const { OperatorsDB } = require('../../../repository/mongoAtlas/operations')

module.exports = app => {

    const collection = "acao"

    // LISTAR TODOS OS acaoS DA BASE DATA3
    app.get('/acao', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection )
        listUseCase.findAll()
    })

    //LISTAR acaoS DE ACORDO POR ID
    app.get('/acao/:id', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        listUseCase.findById(req.params.id)
    })

    //LISTAR acao POR NOME
    app.get('/acao/name/:name', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        listUseCase.findByName(req.params.name)
    })

    //DELETAR POR NOME
    app.delete('/acao/name/:name', function (req, res) {
        const deleteUseCase = new DeleteUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        deleteUseCase.deleteByName(req.params.name)
    })

    //CRIAR acao
    app.post('/acao', function (req, res) {
        new CreateUseCase(new PresenterWEB(res), new OperatorsDB(), req.body, collection).executeSave()
    })

    //ATUALIZAR POR ID
    app.put('/acao/:id', function (req, res) {
        new UpdateUseCase(new PresenterWEB(res), new OperatorsDB(), req.body, collection).execute(req.params.id)
    })

    //DELETAR POR ID
    app.delete('/acao/:id', function (req, res) {
        const deleteUseCase = new DeleteUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        deleteUseCase.delete(req.params.id)
    })



}