const { CreateUseCase } = require('../../../usecases/createusecase')
const { ListUseCase } = require('../../../usecases/listusecase')
const { DeleteUseCase } = require('../../../usecases/deleteusecase')
const { UpdateUseCase } = require('../../../usecases/updateusecase')
const { PresenterWEB } = require('.././../../presenter/presenterweb')
const { OperatorsDB } = require('.././../../repository/mongoAtlas/operations')

module.exports = app => {

    const collection = "fundo"

    // LISTAR TODOS OS FUNDOS DA BASE DATA3
    app.get('/fundo', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection )
        listUseCase.findAll()
    })

    //LISTAR FUNDOS DE ACORDO POR ID
    app.get('/fundo/:id', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        listUseCase.findById(req.params.id)
    })

    //LISTAR FUNDO POR NOME
    app.get('/fundo/name/:name', function (req, res) {
        // console.log('GET')
        const listUseCase = new ListUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        listUseCase.findByName(req.params.name)
    })

    //DELETAR POR NOME
    app.delete('/fundo/name/:name', function (req, res) {
        const deleteUseCase = new DeleteUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        deleteUseCase.deleteByName(req.params.name)
    })

    //CRIAR FUNDO
    app.post('/fundo', function (req, res) {
        new CreateUseCase(new PresenterWEB(res), new OperatorsDB(), req.body, collection).executeSave()
    })

    //ATUALIZAR POR ID
    app.put('/fundo/:id', function (req, res) {
        new UpdateUseCase(new PresenterWEB(res), new OperatorsDB(), req.body, collection).execute(req.params.id)
    })

    //DELETAR POR ID
    app.delete('/fundo/:id', function (req, res) {
        const deleteUseCase = new DeleteUseCase(new PresenterWEB(res), new OperatorsDB(), collection)
        deleteUseCase.delete(req.params.id)
    })



}